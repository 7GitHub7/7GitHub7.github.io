angular.
  module('carmanager').
  component('menu', {  // This name is what AngularJS uses to match to the `<phone-list>` element.
    templateUrl:
        'nav/nav.html',
    controller: function PhoneListController() {
      
    }
  });