var AUTH0_CLIENT_ID='BUIJSW9x60sIHBw8Kd9EmCbj8eDIFxDC';
var AUTH0_DOMAIN='samples.auth0.com';
